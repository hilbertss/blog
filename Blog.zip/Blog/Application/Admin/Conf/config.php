<?php
return array(
	//'配置项'=>'配置值'
	'TMPL_PARSE_STRING'  =>array(     
	'__PUBLIC__' => SITE_URL.'/Application/Admin/Public', // 更改默认的/Public 替换规则     
	),
);