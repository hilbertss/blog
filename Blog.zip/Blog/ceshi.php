<?php
$data2="QUFodHRwOi8vZHgzNS43MDYwLmNvbS8xMzEwLzAxL72tuv7V/bXAL1u9rbr+1f21wF212jG8r19oZC5tcDRaWg==";
echo base64_decode($data2);

